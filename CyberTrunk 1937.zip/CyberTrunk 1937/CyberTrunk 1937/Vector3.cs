﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberTrunk_1937
{
    struct Vector3
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }

        public Vector3(double x, double y, double z)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }
        public static Vector3 operator +(Vector3 v1, Vector3 v2)
        {
            return new Vector3(v1.X + v2.X, v1.Y + v2.Y, v1.Z + v2.Z);
        }
        public static Vector3 operator -(Vector3 v1, Vector3 v2)
        {
            return new Vector3(v1.X - v2.X, v1.Y - v2.Y, v1.Z - v2.Z);
        }
        public static Vector3 operator *(Vector3 v1, double val)
        {
            return new Vector3(v1.X * val, v1.Y * val, v1.Z * val);
        }
        public static Vector3 operator /(Vector3 v1, double val)
        {
            return new Vector3(v1.X / val, v1.Y / val, v1.Z / val);
        }
        public double Dot(Vector3 v)
        {
            return (this.X * v.X + this.Y * v.Y + this.Z * v.Z);
        }
        public static Vector3 Cross(Vector3 vec1, Vector3 vec2)
        {
            return new Vector3(vec1.Y * vec2.Z - vec1.Z * vec2.Y,
                vec1.Z * vec2.X - vec1.X * vec2.Z,
                vec1.X * vec2.Y - vec1.Y * vec2.X);
        }
        public double Length
        { get { return Math.Sqrt(X * X + Y * Y + Z * Z); } }

        public double LengthSq
        { get { return X * X + Y * Y + Z * Z; } }

        public Vector3 Normalised
        { get { return this / this.Length; } }

    }
}
