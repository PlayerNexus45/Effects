﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CyberTrunk_1937
{
    public partial class Form1 : Form
    {
        Color cPink = Color.FromArgb(214, 0, 255);
        Color cPurple = Color.FromArgb(189, 0, 255);
        Color cBlue = Color.FromArgb(0, 30, 255);
        Color cLightBlue = Color.FromArgb(0, 184, 255);
        Color cCyan = Color.FromArgb(0, 255, 159);

        List<Sphere> Spheres = new List<Sphere>();
        LightSource ls = new LightSource(new Vector3(200, 100, 400), Color.White);
        int ballCount = 5;
        Bitmap bmp = new Bitmap(10, 10);
        public Form1()
        {
            InitializeComponent();
            Random rnd = new Random();
            //for (int i = 0; i < ballCount; i++)
            //{
            //    int r = rnd.Next(255);
            //    int g = rnd.Next(255);
            //    int b = rnd.Next(255);
            //    Color ballC = Color.FromArgb(r, g, b);
            //    Spheres.Add(new Sphere(rnd.Next(pictureBox1.Width), rnd.Next(pictureBox1.Height), rnd.Next(5), rnd.Next(100), ballC));
            //}
            
            //Spheres.Add(new Sphere(pictureBox1.Width/2, pictureBox1.Height/2, 30, 30, Color.Blue));
            //Spheres.Add(new Sphere(pictureBox1.Width / 2, pictureBox1.Height / 2, 50, 60, Color.Red));
            Spheres.Add(new Sphere(pictureBox1.Width / 2, pictureBox1.Height / 2, -1, 100, Color.Green));
            comboBox1.SelectedIndex = 0;
        }
        private Color HitTest(List<Sphere> balls, int x, int y)
        {
            Sphere closestSphere = new Sphere(0, 0, double.MaxValue, 1, Color.Black);
            bool changed = false;
            foreach (var ball in balls)
            {
                if (ball.CheckIfInside(x, y))
                {
                    if (ball.z < closestSphere.z)
                    {
                        closestSphere = ball;
                        changed = true;

                    }
                }
                
            }
            if (changed)
            {
                double cos = closestSphere.Angleing(x, y, ls);
                Color pcol = Color.FromArgb(Convert.ToInt32(closestSphere.ballColor.R), Convert.ToInt32(closestSphere.ballColor.G), Convert.ToInt32(closestSphere.ballColor.B));
                return pcol;

            }
            else
            {
                return Color.Black;
            }
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawImage(bmp, 0, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            for (int x = 0; x < bmp.Width; x++)
            {
                for (int y = 0; y < bmp.Height; y++)
                {
                    Color pcol = HitTest(Spheres, x, y);
                    
                    
                    bmp.SetPixel(x, y, pcol);
                }

            }
            pictureBox1.Refresh();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            float[,,] matrixes = new float[4, 3, 3] 
            { 
                { { -1, 0, 1 }, { -1, 1, 1 }, { -1, 0, 1 } } , 
                { { 1f/9f, 1f/9f, 1f/9f }, { 1f/9f, 1f/9f, 1f/9f }, { 1f / 9f, 1f/9f, 1f/9f } } , 
                { { -1, -1, -1 }, { -1, 9, -1 }, { -1, -1, -1 } } , 
                { { 0, 0, 0 }, { -1, 1, 0 }, { 0, 0, 0 } } 
            };

            Bitmap Nbmp = new Bitmap(bmp.Width, bmp.Height);
            int selected = comboBox1.SelectedIndex;
            for (int i = 1; i < bmp.Width-1; i++)
            {
                for (int j = 1; j < bmp.Height-1; j++)
                {
                    float r = 0;
                    float g = 0;
                    float b = 0;
                    for (int k = -1; k <= 1; k++)
                    {
                        for (int l = -1; l <= 1; l++)
                        {
                            r += bmp.GetPixel(i + k, j + l).R * matrixes[selected, k + 1, l + 1];
                            g += bmp.GetPixel(i + k, j + l).G * matrixes[selected, k + 1, l + 1];
                            b += bmp.GetPixel(i + k, j + l).B * matrixes[selected, k + 1, l + 1];
                        }
                    }
                    r = Math.Max(Math.Min(r, 255), 0);
                    g = Math.Max(Math.Min(g, 255), 0);
                    b = Math.Max(Math.Min(b, 255), 0);
                    Color pcol = Color.FromArgb(Convert.ToInt16(r), Convert.ToInt16(g), Convert.ToInt16(b));
                    Nbmp.SetPixel(i, j, pcol);

                }
            }
            bmp = Nbmp;
            pictureBox1.Refresh();
            Cursor.Current = Cursors.Default;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string ls = openFileDialog1.FileName;

                bmp = new Bitmap(ls);
                pictureBox1.Refresh();
            }
        }
    }
}
