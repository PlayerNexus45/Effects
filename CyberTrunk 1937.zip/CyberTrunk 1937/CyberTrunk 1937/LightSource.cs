﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberTrunk_1937
{
    internal class LightSource
    {
        public Vector3 position;
        public Color lightColor;

        public LightSource(Vector3 position, Color lightColor)
        {
            this.position = position;
            this.lightColor = lightColor;
        }
    }
}
