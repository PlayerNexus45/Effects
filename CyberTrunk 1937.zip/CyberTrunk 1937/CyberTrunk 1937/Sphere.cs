﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberTrunk_1937
{
    internal class Sphere
    {
        public double x, y, z, r;
        public Color ballColor;

        public Sphere(double x, double y, double z, double r, Color ballColor)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            this.r = r;
            this.ballColor = ballColor;
        }
        public bool CheckIfInside(int x, int y)
        {
            double d = Math.Sqrt(Math.Pow(this.x - x, 2) + Math.Pow(this.y - y, 2));
            return d <= r;
        }
        public double Angleing(double xp, double yp, LightSource ls)
        {
            double d = Math.Sqrt(Math.Pow(xp - x, 2) + Math.Pow(yp - y, 2));


            double zp = Math.Sqrt(r * r - d*d) + this.x;
            double v1x = xp - x;
            double v1y = yp - y;
            double v1z = zp - z;
            double v2x = ls.position.X - xp;
            double v2y = ls.position.Y - yp;
            double v2z = ls.position.Z - zp;

            double cosin = (v1x * v2x + v1y * v2y + v1z * v2z) / (Math.Sqrt(v1x * v1x + v1y * v1y + v1z * v1z) * Math.Sqrt(v2x * v2x + v2y * v2y + v2z * v2z));
            return Math.Max(cosin, 0);


        }
    }

}
